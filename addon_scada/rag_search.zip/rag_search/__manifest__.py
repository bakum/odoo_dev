{
    'name': 'RAG Semantic Search',
    'version': '17.0.0.1',
    'depends': ['base', 'web'],
    'category': 'Tools',
    'summary': 'Semantic search across documents using FAISS (RAG without generation)',
    'application': True,
    'data': [
        'security/ir.model.access.csv',
        'views/rag_document_views.xml',
        'views/rag_chunk_views.xml',
        'data/rag_menus.xml',
        'data/search_widget.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'rag_search/static/src/js/SemanticSearch.js',
            'rag_search/static/src/js/search.xml',
        ]
    },
    "external_dependencies": {
        "python":
          [
           "PyMuPDF",
           "python-docx",
           "faiss-cpu",
           "numpy",
           "sentence_transformers",
           "langdetect",
           ]
    },
}