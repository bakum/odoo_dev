from sentence_transformers import SentenceTransformer


class EmbedderService:
    model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")