/** @odoo-module **/

import {Component, useState, xml} from "@odoo/owl";
import {useService} from "@web/core/utils/hooks";
import {registry} from "@web/core/registry";

export class SemanticSearch extends Component {
    highlight(text, query) {
        const escaped = query.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
        const pattern = new RegExp(escaped, "gi");
        return text.replace(pattern, (match) => `<mark>${match}</mark>`);
    }

    onKeydown(ev) {
        if (ev.key === "Enter" && !ev.shiftKey) {
            ev.preventDefault();
            this.search();
        }
    }

    setup() {
        this.rpc = useService("rpc");
        this.state = useState({query: "", results: []});
    }

    async search() {
        // const res = await fetch("/rag/search", {
        //     method: "POST",
        //     body: JSON.stringify({query: this.state.query}),
        //     headers: {
        //         "Content-Type": "application/json"
        //     }
        // });
        const raw = await this.rpc("/rag/search", {
            query: this.state.query,
        });
        // const raw = await response.json();
        // Проверка на ошибку
        if (raw.error) {
            console.error("Search error:", raw.error);
            this.state.results = [];
            return;
        }
        this.state.results = raw.results.map(r => ({
            ...r,
            highlighted: this.highlight(r.text, this.state.query)
        }));
    }
}

SemanticSearch.template = "rag_search.SemanticSearch";
registry.category("actions").add("rag_search.search_widget", SemanticSearch);
