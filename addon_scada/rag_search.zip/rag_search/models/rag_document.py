import re

from langdetect import detect

from odoo import models, fields, api
import io, base64
import fitz  # Для PDF
import docx  # Для DOCX
# import nltk
#
# nltk.download('punkt')
# from nltk.tokenize import sent_tokenize


class RagDocument(models.Model):
    _name = "rag.document"
    _description = "RAG Document"

    name = fields.Char(required=True)
    file = fields.Binary("File", required=True)
    filename = fields.Char()
    file_type = fields.Selection([
        ('pdf', 'PDF'),
        ('docx', 'DOCX'),
        ('other', 'Other')
    ], string="File Type")
    chunk_ids = fields.One2many("rag.chunk", "document_id", string="Chunks")
    language = fields.Char("Language")
    preview = fields.Text("Preview", compute="_compute_preview")

    @api.onchange('file', 'name')
    def _compute_filename(self):
        for rec in self:
            if rec.file and rec.name:
                # Устанавливаем имя файла, если оно не задано
                if not rec.filename:
                    rec.filename = f"{rec.name}"
            else:
                rec.filename = ''

    @api.model
    def create(self, vals):
        if 'filename' in vals:
            ext = vals['filename'].split('.')[-1].lower()
            vals['file_type'] = ext if ext in ['pdf', 'docx'] else 'other'
        return super().create(vals)

    def action_reindex(self):
        self._extract_chunks()
        self.env['rag.chunk']._build_index()

    def _extract_chunks(self, chunk_size=5):
        global full_text, text
        for rec in self:
            rec.chunk_ids.unlink()
            if not rec.file or not rec.filename:
                continue

            extension = rec.filename.split('.')[-1].lower()
            data = io.BytesIO(base64.b64decode(rec.file))

            if extension == 'pdf':
                doc = fitz.open(stream=data.read(), filetype="pdf")
                for page_num, page in enumerate(doc, start=1):
                    text = page.get_text()
                    self._create_chunks_from_text(rec, text, page_num, chunk_size)

            elif extension == 'docx':
                document = docx.Document(data)
                full_text = "\n".join([para.text for para in document.paragraphs])
                self._create_chunks_from_text(rec, full_text, page_num=1, chunk_size=chunk_size)

            else:
                raise ValueError(f"Unsupported file type: {extension}")

            try:
                rec.language = detect(full_text if extension == 'docx' else text)
            except Exception:
                rec.language = 'unknown'

    def _simple_sentences(self, text: str):
        # разделяем по точкам, восклицательным, вопросительным
        parts = re.split(r'(?<=[\.\!\?])\s+', text.strip())
        return [p for p in parts if p]

    def _create_chunks_from_text(self, rec, text, page_num, chunk_size):
        # sentences = sent_tokenize(text)
        sentences = self._simple_sentences(text)
        chunks = [' '.join(sentences[i:i + chunk_size]) for i in range(0, len(sentences), chunk_size)]
        cursor = 0
        for idx, chunk in enumerate(chunks):
            start_idx = text.find(chunk, cursor)
            end_idx = start_idx + len(chunk)
            cursor = end_idx
            self.env['rag.chunk'].create({
                'document_id': rec.id,
                'content': chunk,
                'position': idx,
                'page_number': page_num,
                'char_start': start_idx,
                'char_end': end_idx,
            })

    @api.depends('file', 'filename')
    def _compute_preview(self):
        for rec in self:
            if not rec.file or not rec.filename or not rec.filename.endswith('.docx'):
                rec.preview = ''
                continue
            data = io.BytesIO(base64.b64decode(rec.file))
            try:
                document = docx.Document(data)
                rec.preview = "\n".join([p.text for p in document.paragraphs if p.text.strip()])
            except Exception:
                rec.preview = "Ошибка чтения документа."
