import os
import logging

from odoo import http, tools
from odoo.http import request
import numpy as np
import faiss

from ..services.embedder_service import EmbedderService

_logger = logging.getLogger(__name__)

FAISS_INDEX_PATH = tools.config.filestore('llm_index')
os.makedirs(FAISS_INDEX_PATH, exist_ok=True)
INDEX_FILE = os.path.join(FAISS_INDEX_PATH, 'rag_faiss.index')


class RAGSearchController(http.Controller):
    _model = None
    _index = None

    def _init_resources(self):
        if not RAGSearchController._model:
            RAGSearchController._model = EmbedderService.model
        if not RAGSearchController._index:
            try:
                RAGSearchController._index = faiss.read_index(INDEX_FILE)
                _logger.info("✅ FAISS index loaded: %s", INDEX_FILE)
            except Exception as e:
                _logger.error("❌ FAISS index load failed: %s", e)

    @http.route('/rag/search', type='json', auth='user', methods=['POST'])
    def search(self, query, top_k=5, threshold=0.7, **kwargs):
        if not query:
            return {'error': 'Empty query'}

        self._init_resources()
        if not self._index:
            return {'error': 'Index not available'}

        try:
            vec = self._model.encode(query, convert_to_numpy=True).astype('float32')
            vec = vec.reshape(1, -1)
            faiss.normalize_L2(vec)

            D, I = self._index.search(vec, int(top_k))

            chunk_ids = I[0].tolist()
            scores = D[0].tolist()

            records = request.env['rag.chunk'].sudo().browse(chunk_ids)
            id2rec = {r.id: r for r in records}

            results = []
            for idx, chunk_id in enumerate(chunk_ids):
                score = float(scores[idx])
                if chunk_id == -1 or score < float(threshold):
                    continue
                chunk = id2rec.get(chunk_id)
                if not chunk:
                    continue
                results.append({
                    'text': chunk.content,
                    'doc_id': chunk.id,
                    'score': score,
                    'document': chunk.document_id.display_name,
                    'page_number': chunk.page_number,
                    'char_start': chunk.char_start,
                    'char_end': chunk.char_end,
                })

            # сортировка по score убыванию (на всякий случай)
            results.sort(key=lambda r: r['score'], reverse=True)

            return {'results': results}
        except Exception as e:
            _logger.exception("Search error: %s", e)
            return {'error': 'Search failed'}
